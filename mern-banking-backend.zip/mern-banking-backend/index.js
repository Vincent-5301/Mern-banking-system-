const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const Account = require('./models/Account');

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

app.post('/api/accounts', async (req, res) => {
  const { accountNumber, holderName, securityKey, initialBalance } = req.body;
  const account = new Account({ accountNumber, holderName, securityKey, balance: initialBalance });
  await account.save();
  res.send(account);
});

app.post('/api/accounts/:accountNumber/deposit', async (req, res) => {
  const { accountNumber } = req.params;
  const { amount } = req.body;
  const account = await Account.findOne({ accountNumber });
  if (account) {
    account.balance += amount;
    await account.save();
    res.send(account);
  } else {
    res.status(404).send({ message: 'Account not found' });
  }
});

app.post('/api/accounts/:accountNumber/withdraw', async (req, res) => {
  const { accountNumber } = req.params;
  const { amount } = req.body;
  const account = await Account.findOne({ accountNumber });
  if (account) {
    if (account.balance >= amount) {
      account.balance -= amount;
      await account.save();
      res.send(account);
    } else {
      res.status(400).send({ message: 'Insufficient balance' });
    }
  } else {
    res.status(404).send({ message: 'Account not found' });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
