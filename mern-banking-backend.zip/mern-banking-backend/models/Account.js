const mongoose = require('mongoose');

const accountSchema = new mongoose.Schema({
  accountNumber: String,
  holderName: String,
  securityKey: String,
  balance: Number,
});

module.exports = mongoose.model('Account', accountSchema);
